import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <aside class="tlo-sidebar">
      <nav class="nav-links">
        <a routerLink="/dashboard" routerLinkActive="active" class="nav-item">
          📊 Dashboard
        </a>
        <a routerLink="/rules" routerLinkActive="active" class="nav-item">
          ⚙️ Rules
        </a>
        <a routerLink="/planning" routerLinkActive="active" class="nav-item">
          🛤️ Planning
        </a>
        <a routerLink="/saved-plans" routerLinkActive="active" class="nav-item">
          📁 Saved Plans
        </a>
      </nav>
    </aside>
  `,
  styles: [`
    .tlo-sidebar {
      width: 220px;
      background: #1f2937;
      color: #9ca3af;
      display: flex;
      flex-direction: column;
      height: calc(100vh - 60px);
      .nav-links { display: flex; flex-direction: column; padding-top: 16px; }
      .nav-item {
        padding: 12px 20px;
        color: #d1d5db;
        text-decoration: none;
        font-size: 14px;
        display: flex;
        align-items: center;
        gap: 12px;
        transition: background 0.2s;
        &:hover, &.active { background: #374151; color: #ffffff; border-left: 4px solid #dc2626; }
      }
    }
  `]
})
export class SidebarComponent {}
