import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { SavedPlan, OptimizationResult, Container } from '../models/tlo.models';

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private baseUrl = 'http://localhost:8000/api';

  constructor(private http: HttpClient) {}

  getSavedPlans(): Observable<SavedPlan[]> {
    return of([
      { planId: 42, trainNumber: 'AZ11431', runDate: 'Jul 24, 2026, 1:42:02 PM', totalContainers: 802, totalRailcars: 50, status: 'SAVED' },
      { planId: 24, trainNumber: 'AZ11431', runDate: 'Jul 17, 2026, 7:24:41 AM', totalContainers: 968, totalRailcars: 50, status: 'SAVED' },
      { planId: 17, trainNumber: 'AZ11431', runDate: 'Jul 17, 2026, 6:21:13 AM', totalContainers: 802, totalRailcars: 50, status: 'SAVED' },
      { planId: 11, trainNumber: 'AZ11431', runDate: 'Jul 16, 2026, 11:58:39 AM', totalContainers: 802, totalRailcars: 50, status: 'SAVED' },
      { planId: 10, trainNumber: 'AZ11431', runDate: 'Jul 16, 2026, 11:57:44 AM', totalContainers: 802, totalRailcars: 50, status: 'SAVED' },
      { planId: 7, trainNumber: 'AZ11431', runDate: 'Jul 16, 2026, 11:48:37 AM', totalContainers: 140, totalRailcars: 15, status: 'SAVED' },
      { planId: 4, trainNumber: 'AZ11431', runDate: 'Jul 14, 2026, 8:10:13 PM', totalContainers: 802, totalRailcars: 50, status: 'SAVED' }
    ]);
  }

  runOptimization(payload: any): Observable<OptimizationResult> {
    return of({
      planId: 'Plan-AZ-2026-08-26-1822',
      trainNumber: 'AZ11431',
      runDate: 'Aug 26, 2026, 6:22:02 PM',
      slotUtilizationPercentage: 87,
      slotsFilled: 207,
      totalSlots: 238,
      liftsPerIMU: 1.75,
      craneMoveDistanceFt: 8586,
      totalContainersLoaded: 207,
      containersSetAside: 155,
      containersUnassigned: 310,
      containers: [
        { equipmentNumber: 'AZSU206811', carRod: 1, dcc: 3, containerLocation: 'AMV2T 30 1 P', destination: 'ADO PQ', genset: 'No', damage: 'NONE', track: 'S116', railCar: 'MAV602653', aarCarKind: 'S610', wellID: '249', slotID: 637, slotType: 'BOTTOM', subPosition: 'SINGLE' },
        { equipmentNumber: 'JCZ97479', carRod: 1, dcc: 3, containerLocation: 'WL22 20 3 1', destination: 'ADO PQ', genset: 'No', damage: 'NONE', track: 'S116', railCar: 'MAV602653', aarCarKind: 'S610', wellID: '249', slotID: 484, slotType: 'TOP', subPosition: 'SINGLE' },
        { equipmentNumber: 'JC543431', carRod: 1, dcc: 3, containerLocation: 'AMV2Y 30 2 1', destination: 'ADO PQ', genset: 'No', damage: 'MINOR', track: 'S116', railCar: 'MAV603482', aarCarKind: 'S610', wellID: '249', slotID: 603, slotType: 'BOTTOM', subPosition: 'SINGLE' },
        { equipmentNumber: 'AZSU281121', carRod: 1, dcc: 3, containerLocation: 'AMVVS 30 2 1', destination: 'ADO PQ', genset: 'No', damage: 'NONE', track: 'S116', railCar: 'MAV603482', aarCarKind: 'S610', wellID: '249', slotID: 485, slotType: 'TOP', subPosition: 'SINGLE' },
        { equipmentNumber: 'AMA541004', carRod: 7, dcc: 3, containerLocation: 'NL19 12 2 2', destination: 'EL', genset: 'Yes', damage: 'NONE', track: 'S116', railCar: 'MT786767', aarCarKind: 'S635', wellID: '334', slotID: 678, slotType: 'BOTTOM', subPosition: 'SINGLE' }
      ]
    });
  }
}
