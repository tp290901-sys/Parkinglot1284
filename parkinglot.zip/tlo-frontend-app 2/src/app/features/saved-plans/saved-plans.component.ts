import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../core/services/api.service';
import { SavedPlan } from '../../core/models/tlo.models';

@Component({
  selector: 'app-saved-plans',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="saved-plans-container">
      <h2>Saved Plans</h2>
      <p class="subtitle">View and manage your saved optimization runs.</p>
      
      <table class="tlo-table">
        <thead>
          <tr>
            <th>Plan ID</th>
            <th>Train Number</th>
            <th>Run Date</th>
            <th>Total Containers</th>
            <th>Total Railcars</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let plan of plans">
            <td>{{ plan.planId }}</td>
            <td>{{ plan.trainNumber }}</td>
            <td>{{ plan.runDate }}</td>
            <td>{{ plan.totalContainers }}</td>
            <td>{{ plan.totalRailcars }}</td>
            <td><span class="status-badge">{{ plan.status }}</span></td>
          </tr>
        </tbody>
      </table>
    </div>
  `,
  styles: [`
    .saved-plans-container { padding: 24px; background: #fff; min-height: 100%; }
    .subtitle { color: #6b7280; margin-bottom: 20px; }
    .tlo-table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 14px; }
    .tlo-table th, .tlo-table td { border-bottom: 1px solid #e5e7eb; padding: 12px; text-align: left; }
    .tlo-table th { background: #f9fafb; font-weight: 600; color: #374151; }
    .status-badge { background: #e0f2fe; color: #0369a1; padding: 4px 8px; border-radius: 4px; font-weight: 600; font-size: 12px; }
  `]
})
export class SavedPlansComponent implements OnInit {
  plans: SavedPlan[] = [];

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.apiService.getSavedPlans().subscribe(data => {
      this.plans = data;
    });
  }
}
