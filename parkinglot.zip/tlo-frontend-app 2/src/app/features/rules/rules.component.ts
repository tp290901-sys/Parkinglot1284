import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-rules',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="rules-container">
      <h2>Rules & Constraints Management</h2>
      <p class="subtitle">Configure stacking constraints, hazmat separation, and railcar weight limits.</p>
      <div class="rules-list">
        <div class="rule-card">
          <h4>Rule #1: Max Weight Threshold per Well</h4>
          <p>Ensures total container stack weights do not exceed AAR car tolerances.</p>
          <span class="badge active">Active</span>
        </div>
        <div class="rule-card">
          <h4>Rule #2: Genset Separation Protocol</h4>
          <p>Requires reefer units requiring power to be allocated to compatible slots.</p>
          <span class="badge active">Active</span>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .rules-container { padding: 24px; }
    .subtitle { color: #6b7280; margin-bottom: 20px; }
    .rules-list { display: flex; flex-direction: column; gap: 15px; }
    .rule-card { background: white; padding: 16px; border-radius: 6px; border: 1px solid #e5e7eb; position: relative; }
    .badge { position: absolute; top: 16px; right: 16px; background: #d1fae5; color: #065f46; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: 600; }
  `]
})
export class RulesComponent {}
