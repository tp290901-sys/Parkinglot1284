import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

@Component({
  selector: 'app-dashboard-container',
  standalone: true,
  imports: [CommonModule, RouterModule],
  template: `
    <div class="dashboard-container">
      <h2>TLO Dashboard</h2>
      <p class="subtitle">Overview of yard capacity, active trains, and quick optimization shortcuts.</p>
      
      <div class="metrics-grid">
        <div class="card">
          <h4>Average Slot Utilization</h4>
          <span class="metric-value">84.2%</span>
        </div>
        <div class="card">
          <h4>Units in Yard</h4>
          <span class="metric-value">1,420</span>
        </div>
        <div class="card">
          <h4>Active Trains Scheduled</h4>
          <span class="metric-value">6</span>
        </div>
      </div>

      <div class="quick-actions">
        <h3>Quick Actions</h3>
        <button routerLink="/planning" class="btn-primary">Start New Planning Run</button>
        <button routerLink="/saved-plans" class="btn-secondary">View Saved Plans</button>
      </div>
    </div>
  `,
  styles: [`
    .dashboard-container { padding: 24px; background: #f9fafb; min-height: 100%; }
    .subtitle { color: #6b7280; margin-bottom: 24px; }
    .metrics-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; margin-bottom: 30px; }
    .card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .metric-value { font-size: 28px; font-weight: bold; color: #111827; margin-top: 8px; display: block; }
    .quick-actions { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .btn-primary { background: #dc2626; color: white; border: none; padding: 10px 16px; border-radius: 6px; cursor: pointer; margin-right: 10px; font-weight: 500; }
    .btn-secondary { background: #e5e7eb; color: #374151; border: none; padding: 10px 16px; border-radius: 6px; cursor: pointer; font-weight: 500; }
  `]
})
export class DashboardContainerComponent {}
