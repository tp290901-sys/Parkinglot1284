export interface TrainConfig {
  trainNumber: string;
  railCarsCount: number;
  totalSlots: number;
  maxWeightKg: number;
}

export interface Container {
  equipmentNumber: string;
  carRod: number;
  dcc: number;
  containerLocation: string;
  destination: string;
  genset: 'Yes' | 'No';
  damage: 'YES' | 'NONE';
  track: string;
  railCar: string;
  aarCarKind: string;
  wellID: string;
  slotID: number;
  slotType: 'TOP' | 'BOTTOM' | 'SINGLE';
  subPosition: string;
  status?: string;
}

export interface OptimizationResult {
  planId: string;
  trainNumber: string;
  runDate: string;
  slotUtilizationPercentage: number;
  slotsFilled: number;
  totalSlots: number;
  liftsPerIMU: number;
  craneMoveDistanceFt: number;
  totalContainersLoaded: number;
  containersSetAside: number;
  containersUnassigned: number;
  containers: Container[];
}

export interface SavedPlan {
  planId: number | string;
  trainNumber: string;
  runDate: string;
  totalContainers: number;
  totalRailcars: number;
  status: string;
}
