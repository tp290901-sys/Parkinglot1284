import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../../core/services/api.service';
import { OptimizationResult } from '../../../core/models/tlo.models';

@Component({
  selector: 'app-planning-wizard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="planning-wizard">
      <div class="wizard-steps-header">
        <div [class.active]="step === 1" class="step-tab">1. Select Train</div>
        <div [class.active]="step === 2" class="step-tab">2. Configure Filters</div>
        <div [class.active]="step === 3" class="step-tab">3. Review & Run</div>
        <div [class.active]="step === 4" class="step-tab">4. Result</div>
      </div>

      <div *ngIf="step === 1" class="step-content">
        <h3>Select Train & Rail Car Configuration</h3>
        <div class="form-group">
          <label>Train Number</label>
          <input type="text" value="AZ11431" class="form-control" />
        </div>
        <div class="form-group">
          <label>Rail Cars Count</label>
          <input type="number" value="50" class="form-control" />
        </div>
        <button (click)="step = 2" class="btn-primary">Next: Configure Filters</button>
      </div>

      <div *ngIf="step === 2" class="step-content">
        <h3>Container Filtering & Template Selection</h3>
        <p>Select yard zones and priority criteria for loading.</p>
        <div class="checkbox-group">
          <label><input type="checkbox" checked /> Prioritize destination-based grouping</label><br/>
          <label><input type="checkbox" checked /> Exclude damaged containers (DAMAGED: YES)</label>
        </div>
        <div class="btn-group" style="margin-top: 20px;">
          <button (click)="step = 1" class="btn-secondary">Back</button>
          <button (click)="step = 3" class="btn-primary">Next: Review & Run</button>
        </div>
      </div>

      <div *ngIf="step === 3" class="step-content">
        <h3>Review Selected Configuration</h3>
        <ul class="review-list">
          <li><strong>Train Number:</strong> AZ11431</li>
          <li><strong>Total Railcars:</strong> 50</li>
          <li><strong>Filter Profile:</strong> Standard Yard Constraints v2</li>
        </ul>
        <div class="btn-group" style="margin-top: 20px;">
          <button (click)="step = 2" class="btn-secondary">Back</button>
          <button (click)="executeOptimization()" class="btn-success">Run Optimization</button>
        </div>
      </div>

      <div *ngIf="step === 4" class="step-content result-view">
        <div *ngIf="resultData">
          <div class="success-banner">
            <span class="icon">✅</span>
            <div>
              <h4>Success</h4>
              <p>{{ resultData.planId }} | Train: {{ resultData.trainNumber }} | Date: {{ resultData.runDate }}</p>
            </div>
          </div>

          <div class="metrics-dashboard-grid">
            <div class="metric-card">
              <div class="circular-progress">{{ resultData.slotUtilizationPercentage }}%</div>
              <span>Slot Utilization<br/><small>{{ resultData.slotsFilled }} of {{ resultData.totalSlots }} slots filled</small></span>
            </div>
            <div class="metric-card">
              <h4>{{ resultData.liftsPerIMU }}</h4>
              <span>Lifts per IMU<br/><small>total lifts / total loaded containers</small></span>
            </div>
            <div class="metric-card">
              <h4>{{ resultData.craneMoveDistanceFt | number }} ft</h4>
              <span>Crane Move Distance In Given Order</span>
            </div>
            <div class="metric-card">
              <h4>{{ resultData.totalContainersLoaded }}</h4>
              <span>Total Containers Loaded in Train</span>
            </div>
            <div class="metric-card">
              <h4>{{ resultData.containersSetAside }}</h4>
              <span>Containers Set Aside (Not Loaded)</span>
            </div>
            <div class="metric-card alert">
              <h4>{{ resultData.containersUnassigned }}</h4>
              <span>Containers Left to Load (Unassigned)</span>
            </div>
          </div>

          <div class="table-section">
            <h3>Container Loading Plan</h3>
            <table class="tlo-table">
              <thead>
                <tr>
                  <th>Seq</th>
                  <th>Equipment Number</th>
                  <th>Car Rod</th>
                  <th>DCC</th>
                  <th>Container Location</th>
                  <th>Destination</th>
                  <th>Genset</th>
                  <th>Damage</th>
                  <th>Track</th>
                  <th>Rail Car</th>
                  <th>AAR CarKind</th>
                  <th>Well ID</th>
                  <th>Slot ID</th>
                  <th>Slot Type</th>
                </tr>
              </thead>
              <tbody>
                <tr *ngFor="let c of resultData.containers; let i = index">
                  <td>{{ i + 1 }}</td>
                  <td>{{ c.equipmentNumber }}</td>
                  <td>{{ c.carRod }}</td>
                  <td>{{ c.dcc }}</td>
                  <td>{{ c.containerLocation }}</td>
                  <td>{{ c.destination }}</td>
                  <td>{{ c.genset }}</td>
                  <td>{{ c.damage }}</td>
                  <td>{{ c.track }}</td>
                  <td>{{ c.railCar }}</td>
                  <td>{{ c.aarCarKind }}</td>
                  <td>{{ c.wellID }}</td>
                  <td>{{ c.slotID }}</td>
                  <td>{{ c.slotType }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .planning-wizard { padding: 24px; background: #f3f4f6; min-height: 100vh; }
    .wizard-steps-header { display: flex; background: white; border-radius: 8px; overflow: hidden; margin-bottom: 20px; box-shadow: 0 1px 2px rgba(0,0,0,0.05); }
    .step-tab { flex: 1; padding: 14px; text-align: center; font-weight: 600; color: #6b7280; background: #f9fafb; border-bottom: 3px solid transparent; }
    .step-tab.active { color: #dc2626; background: white; border-bottom: 3px solid #dc2626; }
    .step-content { background: white; padding: 24px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.1); }
    .form-group { margin-bottom: 16px; }
    .form-control { width: 100%; padding: 8px 12px; border: 1px solid #d1d5db; border-radius: 4px; margin-top: 6px; }
    .btn-primary { background: #dc2626; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-weight: 600; }
    .btn-secondary { background: #e5e7eb; color: #374151; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-weight: 600; margin-right: 10px; }
    .btn-success { background: #059669; color: white; border: none; padding: 10px 20px; border-radius: 4px; cursor: pointer; font-weight: 600; }
    .metrics-dashboard-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 16px; margin: 20px 0; }
    .metric-card { background: #f9fafb; border: 1px solid #e5e7eb; padding: 16px; border-radius: 6px; text-align: center; }
    .metric-card.alert { border-color: #f87171; background: #fef2f2; }
    .circular-progress { font-size: 24px; font-weight: bold; color: #059669; margin-bottom: 6px; }
    .tlo-table { width: 100%; border-collapse: collapse; margin-top: 15px; font-size: 13px; }
    .tlo-table th, .tlo-table td { border: 1px solid #e5e7eb; padding: 8px; text-align: left; }
    .tlo-table th { background: #f3f4f6; font-weight: 600; }
    .success-banner { display: flex; align-items: center; gap: 12px; background: #ecfdf5; border: 1px solid #a7f3d0; padding: 16px; border-radius: 6px; margin-bottom: 20px; }
  `]
})
export class PlanningWizardComponent {
  step = 1;
  resultData: OptimizationResult | null = null;

  constructor(private apiService: ApiService) {}

  executeOptimization() {
    this.apiService.runOptimization({}).subscribe(res => {
      this.resultData = res;
      this.step = 4;
    });
  }
}
