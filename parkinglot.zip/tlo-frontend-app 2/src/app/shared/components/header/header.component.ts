import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [CommonModule],
  template: `
    <header class="tlo-header">
      <div class="brand-section">
        <h2 class="logo-text">TLO</h2>
        <span class="sub-text">Train Load Optimization</span>
      </div>
      <div class="user-profile">
        <span class="user-role">Super Admin User</span>
        <div class="avatar-icon">👤</div>
      </div>
    </header>
  `,
  styles: [`
    .tlo-header {
      height: 60px;
      background: #ffffff;
      border-bottom: 1px solid #e5e7eb;
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0 24px;
      .brand-section { display: flex; align-items: baseline; gap: 12px; }
      .logo-text { font-size: 20px; font-weight: 700; color: #dc2626; margin: 0; }
      .sub-text { font-size: 12px; color: #6b7280; }
      .user-profile { display: flex; align-items: center; gap: 10px; font-weight: 500; font-size: 14px; }
      .avatar-icon { background: #f3f4f6; padding: 6px 10px; border-radius: 50%; }
    }
  `]
})
export class HeaderComponent {}
