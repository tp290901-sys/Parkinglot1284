import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { DashboardContainerComponent } from './features/dashboard/dashboard-container/dashboard-container.component';
import { RulesComponent } from './features/rules/rules.component';
import { PlanningWizardComponent } from './features/planning/planning-wizard/planning-wizard.component';
import { SavedPlansComponent } from './features/saved-plans/saved-plans.component';

export const routes: Routes = [
  { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
  { path: 'dashboard', component: DashboardContainerComponent, canActivate: [authGuard] },
  { path: 'rules', component: RulesComponent, canActivate: [authGuard] },
  { path: 'planning', component: PlanningWizardComponent, canActivate: [authGuard] },
  { path: 'saved-plans', component: SavedPlansComponent, canActivate: [authGuard] },
  { path: '**', redirectTo: 'dashboard' }
];
